from setuptools import setup

setup(
    name='resnext',
    version='0.1dev',
    packages=['resnext'],
    test_suite='nose.collector',
    tests_require=['nose'],
)
