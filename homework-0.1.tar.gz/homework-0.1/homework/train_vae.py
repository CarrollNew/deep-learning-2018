import argparse
import logging
import os

import torch
import torchvision.datasets as datasets
from torch.optim import Adam
from torchvision import transforms

from vae.vae import VAE
from vae.trainer import Trainer as VAETrainer
from vae.vae import loss_function as vae_loss_function


def get_config():
    parser = argparse.ArgumentParser(description='Training VAE on CIFAR10')

    parser.add_argument('--log-root', type=str, default='../logs')
    parser.add_argument('--data-root', type=str, default='data')
    parser.add_argument('--log-name', type=str, default='train_vae.log')
    parser.add_argument('--cuda', action='store_false', default=False,
                       help='enables CUDA training')
    parser.add_argument('--batch-size', type=int, default=32,
                        help='input batch size for training')
    parser.add_argument('--epochs', type=int, default=1,
                        help='number of epochs to train')
    parser.add_argument('--image-size', type=int, default=28,
                        help='size of images to generate')
    config = parser.parse_args()
    config.cuda = config.cuda and torch.cuda.is_available()

    return config

def main():
    config = get_config()
    logging.basicConfig(
        format='%(asctime)s | %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(config.log_root,
                                             config.log_name)),
            logging.StreamHandler()],
        level=logging.INFO)

    transform = transforms.Compose([transforms.Resize(config.image_size), transforms.ToTensor()])
    train_dataset = datasets.CIFAR10(root=config.data_root, download=True,
                               transform=transform, train=True)
    test_dataset = datasets.CIFAR10(root=config.data_root, download=True,
                               transform=transform, train=False)
    
    
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=config.batch_size, shuffle=True, num_workers=4, pin_memory=True)

    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=config.batch_size, shuffle=True, num_workers=4, pin_memory=True)
    
    vae_model = VAE(image_size=config.image_size)
    trainer = VAETrainer(vae_model, train_loader=train_loader, test_loader=test_loader, optimizer=Adam(vae_model.parameters(), lr=1e-3), loss_function=vae_loss_function)
    
    for epoch in range(config.epochs):
        trainer.train(epoch, log_interval=2)
        trainer.test(epoch, config.batch_size, log_interval=2)   


if __name__ == '__main__':
    main()
