from distutils.core import setup

setup(name='homework',
      version='0.1',
      packages=['homework'])
